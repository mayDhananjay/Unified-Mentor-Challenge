const sliderTabs = document.querySelectorAll(".slider-tab");
const sliderIndicator = document.querySelector(".slider-indicator");

const updatePagination = (tab) => {
  sliderIndicator.style.transform = `translateX(${tab.offsetLeft}px)`;
  sliderIndicator.style.width = `${tab.offsetWidth}px`;
};

const swiper = new Swiper(".swiper", {
  effect: "slide",
  loop: false,
  speed: 1000,
  navigation: {
    nextEl: ".swiper-button-next",
    prevEl: ".swiper-button-prev",
  },
  on: {
    slideChange: () => {
      updatePagination(sliderTabs[swiper.activeIndex]);
    },
  },
});

sliderTabs.forEach((tab, index) => {
  tab.addEventListener("click", () => {
    swiper.slideTo(index);
    updatePagination(tab);
  });
});

updatePagination(sliderTabs[0]);

window.addEventListener("resize", () => {
  updatePagination(sliderTabs[swiper.activeIndex]);
});
