gsap.registerPlugin(ScrollTrigger, ScrollSmoother);

ScrollSmoother.create({
  wrapper: "#smooth-wrapper",
  content: "#smooth-content",
  smooth: 1.3,   // time (seconds)
  effects: true  // enable data-speed, data-lag etc.
});

 
 
 gsap.
registerPlugin
(
ScrollTrigger
);  
 gsap.from("#parent-text ",{
  opacity:0,
  duration:.5,
  y:30,
  delay:1,
  stagger:1
})
var tl=gsap.timeline()
tl.from("#nav_ul a",{
  y:-20,
  opacity:0,
  duration:1,
  stagger:0.3,

})
gsap.from("#about ",{
  opacity:0,
  duration:.5,
  y:30,
  delay:1,
  stagger:1,
  scrollTrigger:{
    trigger:"#about",
    scroller:"body",
    
  }
})
gsap.from("#service_img ",{
  opacity:0,
  duration:.5,
  y:30,
  delay:1,
  stagger:1,
  scrollTrigger:{
    trigger:"#services",
    scroller:"body",
    
  }
})
gsap.from("#contact ",{
  opacity:0,
  duration:.5,
  y:30,
  delay:1,
  stagger:1,
  scrollTrigger:{
    trigger:"#contact",
    scroller:"body",
    
  }
})
gsap.from("#card ",{
  opacity:0,
  duration:.5,
  y:30,
  delay:1,
  stagger:1,
  scrollTrigger:{
    trigger:"#projectHadding",
    scroller:"body",
    
  }
})



let finalPath = "M 10 100 Q 250 100 990 100";


document.querySelectorAll(".string").forEach((el) => {
  el.addEventListener("mousemove", function (dets) {
    const bounds = this.getBoundingClientRect();
    let x = dets.clientX - bounds.left;
    let y = dets.clientY - bounds.top;

    // clamp Y to avoid overflow
    y = Math.max(50, Math.min(y, 150));
    let path = `M 10 100 Q ${x} ${y} 990 100`;

    gsap.to(this.querySelector("path"), {
      attr: { d: path },
      duration: 0.2,
      ease: "elastic.out(1,0.2)",
    });
  });

  el.addEventListener("mouseleave", function () {
    gsap.to(this.querySelector("path"), {
      attr: { d: finalPath },
      duration: 1.5,
      ease: "elastic.out(1, 0.2)",
    });
  });
});




var typed = new Typed("#element", {
  strings: [
    "Not just websites — experiences",
    " Pixel-perfect design.",
    "Responsive. Interactive. Clean.",
    " Transforming ideas into code...",
    "Your vision, my code.",
  ],
  typeSpeed: 60,
});
  const scriptURL = 'https://script.google.com/macros/s/AKfycbztLDOWfCJVc3D03N_lQNxReAkRTWr4bFOGc3RaHWxz6eTYe3PMhbjpLzzRM9vYiTUh/exec'
  const form = document.forms['submit-to-google-sheet']

  form.addEventListener('submit', e => {
    e.preventDefault()
    fetch(scriptURL, { method: 'POST', body: new FormData(form)})
      .then(response => console.log('Success!', response))
      .catch(error => console.error('Error!', error.message))
  })



