gsap.registerPlugin(ScrollTrigger, ScrollSmoother);

ScrollSmoother.create({
  wrapper: "#smooth-wrapper",
  content: "#smooth-content",
  smooth: 1.3,   // time (seconds)
  effects: true  // enable data-speed, data-lag etc.
});

 
 
 gsap.
registerPlugin
(
ScrollTrigger
);  
 gsap.from("#parent-text ",{
  opacity:0,
  duration:.5,
  y:30,
  delay:1,
  stagger:1
})
var tl=gsap.timeline()
tl.from("#nav_ul a",{
  y:-20,
  opacity:0,
  duration:1,
  stagger:0.3,

})
gsap.from("#about ",{
  opacity:0,
  duration:.5,
  y:30,
  delay:1,
  stagger:1,
  scrollTrigger:{
    trigger:"#about",
    scroller:"body",
    
  }
})
gsap.from("#service_img ",{
  opacity:0,
  duration:.5,
  y:30,
  delay:1,
  stagger:1,
  scrollTrigger:{
    trigger:"#services",
    scroller:"body",
    
  }
})
gsap.from("#contact ",{
  opacity:0,
  duration:.5,
  y:30,
  delay:1,
  stagger:1,
  scrollTrigger:{
    trigger:"#contact",
    scroller:"body",
    
  }
})
gsap.from("#card ",{
  opacity:0,
  duration:.5,
  y:30,
  delay:1,
  stagger:1,
  scrollTrigger:{
    trigger:"#projectHadding",
    scroller:"body",
    
  }
})



let finalPath = "M 10 100 Q 250 100 990 100";


document.querySelectorAll(".string").forEach((el) => {
  el.addEventListener("mousemove", function (dets) {
    const bounds = this.getBoundingClientRect();
    let x = dets.clientX - bounds.left;
    let y = dets.clientY - bounds.top;

    // clamp Y to avoid overflow
    y = Math.max(50, Math.min(y, 150));
    let path = `M 10 100 Q ${x} ${y} 990 100`;

    gsap.to(this.querySelector("path"), {
      attr: { d: path },
      duration: 0.2,
      ease: "elastic.out(1,0.2)",
    });
  });

  el.addEventListener("mouseleave", function () {
    gsap.to(this.querySelector("path"), {
      attr: { d: finalPath },
      duration: 1.5,
      ease: "elastic.out(1, 0.2)",
    });
  });
});




var typed = new Typed("#element", {
  strings: [
    "Not just websites — experiences",
    " Pixel-perfect design.",
    "Responsive. Interactive. Clean.",
    " Transforming ideas into code...",
    "Your vision, my code.",
  ],
  typeSpeed: 60,
});
// Skills Animation
gsap.from(".skill-item", {
  opacity: 0,
  duration: 0.8,
  y: 30,
  stagger: 0.2,
  scrollTrigger: {
    trigger: "#skills",
    scroller: "body",
    start: "top 80%"
  }
});

// Animate skill progress bars when they come into view
function animateSkillBars() {
  const skillBars = document.querySelectorAll('.skill-progress');
  
  skillBars.forEach(bar => {
    const percentage = bar.getAttribute('data-skill');
    
    gsap.to(bar, {
      width: percentage + '%',
      duration: 2,
      ease: "power2.out",
      scrollTrigger: {
        trigger: bar,
        scroller: "body",
        start: "top 85%",
        once: true
      }
    });
  });
}

// Call the function after DOM is loaded
document.addEventListener('DOMContentLoaded', animateSkillBars);

// Contact Form Enhancement
const scriptURL = 'https://script.google.com/macros/s/AKfycbztLDOWfCJVc3D03N_lQNxReAkRTWr4bFOGc3RaHWxz6eTYe3PMhbjpLzzRM9vYiTUh/exec'
const form = document.forms['submit-to-google-sheet']
const submitBtn = document.getElementById('Submit');
const successMessage = document.getElementById('success-message');
const errorMessage = document.getElementById('error-message');

// Hide any existing messages
function hideMessages() {
  successMessage.style.display = 'none';
  errorMessage.style.display = 'none';
}

// Show success message with animation
function showSuccessMessage() {
  hideMessages();
  successMessage.style.display = 'block';
  successMessage.style.opacity = '0';
  
  // Animate in
  gsap.to(successMessage, {
    opacity: 1,
    y: 0,
    duration: 0.5,
    ease: "power2.out"
  });
  
  // Auto hide after 5 seconds
  setTimeout(() => {
    gsap.to(successMessage, {
      opacity: 0,
      y: -20,
      duration: 0.3,
      ease: "power2.in",
      onComplete: () => {
        successMessage.style.display = 'none';
      }
    });
  }, 5000);
}

// Show error message with animation
function showErrorMessage() {
  hideMessages();
  errorMessage.style.display = 'block';
  errorMessage.style.opacity = '0';
  
  // Animate in
  gsap.to(errorMessage, {
    opacity: 1,
    y: 0,
    duration: 0.5,
    ease: "power2.out"
  });
  
  // Auto hide after 5 seconds
  setTimeout(() => {
    gsap.to(errorMessage, {
      opacity: 0,
      y: -20,
      duration: 0.3,
      ease: "power2.in",
      onComplete: () => {
        errorMessage.style.display = 'none';
      }
    });
  }, 5000);
}

form.addEventListener('submit', e => {
  e.preventDefault();
  
  // Hide any existing messages
  hideMessages();
  
  // Change button text and disable it
  submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin me-2"></i>Sending...';
  submitBtn.disabled = true;
  submitBtn.classList.add('btn-secondary');
  submitBtn.classList.remove('btn-outline-primary');
  
  fetch(scriptURL, { method: 'POST', body: new FormData(form)})
    .then(response => {
      console.log('Success!', response);
      
      // Show success message
      showSuccessMessage();
      
      // Update button to success state
      submitBtn.innerHTML = '<i class="fa-solid fa-check me-2"></i>Message Sent!';
      submitBtn.classList.remove('btn-secondary');
      submitBtn.classList.add('btn-success');
      
      // Reset form
      form.reset();
      
      // Reset button after 3 seconds
      setTimeout(() => {
        submitBtn.innerHTML = 'Submit';
        submitBtn.disabled = false;
        submitBtn.classList.remove('btn-success');
        submitBtn.classList.add('btn-outline-primary');
      }, 3000);
    })
    .catch(error => {
      console.error('Error!', error.message);
      
      // Show error message
      showErrorMessage();
      
      // Update button to error state
      submitBtn.innerHTML = '<i class="fa-solid fa-exclamation-triangle me-2"></i>Error! Try Again';
      submitBtn.classList.remove('btn-secondary');
      submitBtn.classList.add('btn-danger');
      
      // Reset button after 3 seconds
      setTimeout(() => {
        submitBtn.innerHTML = 'Submit';
        submitBtn.disabled = false;
        submitBtn.classList.remove('btn-danger');
        submitBtn.classList.add('btn-outline-primary');
      }, 3000);
    });
})



