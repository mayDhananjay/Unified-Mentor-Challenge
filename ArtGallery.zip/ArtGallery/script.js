import { db } from './firebaseScript.js';
import { collection, getDocs } from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";



// Modern Professional Navbar JavaScript
class ModernNavbar {
    constructor() {
        this.navbar = document.querySelector('.navbar');
        this.navToggle = document.querySelector('.nav-toggle');
        this.navMenu = document.querySelector('.nav-menu');
        this.navLinks = document.querySelectorAll('.nav-link');
        
        this.init();
    }
    
    init() {
        this.bindEvents();
        this.handleScroll();
        this.addLoadingAnimation();
    }
    
    bindEvents() {
        // Mobile menu toggle
        this.navToggle?.addEventListener('click', (e) => {
            e.preventDefault();
            this.toggleMobileMenu();
        });
        
        // Close mobile menu when clicking on links
        this.navLinks.forEach(link => {
            link.addEventListener('click', () => {
                this.closeMobileMenu();
            });
        });
        
        // Handle scroll effects
        window.addEventListener('scroll', () => {
            this.handleScroll();
        });
        
        // Close mobile menu on resize if open
        window.addEventListener('resize', () => {
            if (window.innerWidth > 768) {
                this.closeMobileMenu();
            }
        });
        
        // Close mobile menu when clicking outside
        document.addEventListener('click', (e) => {
            if (!this.navbar.contains(e.target) && this.navMenu.classList.contains('active')) {
                this.closeMobileMenu();
            }
        });
        
        // Keyboard navigation
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.navMenu.classList.contains('active')) {
                this.closeMobileMenu();
            }
        });
    }
    
    toggleMobileMenu() {
        const isActive = this.navMenu.classList.contains('active');
        
        if (isActive) {
            this.closeMobileMenu();
        } else {
            this.openMobileMenu();
        }
    }
    
    openMobileMenu() {
        this.navMenu.classList.add('active');
        this.navToggle.classList.add('active');
        
        // Prevent body scroll when menu is open
        document.body.style.overflow = 'hidden';
        
        // Add stagger animation to menu items
        this.navLinks.forEach((link, index) => {
            link.parentElement.style.animationDelay = `${index * 0.1}s`;
        });
    }
    
    closeMobileMenu() {
        this.navMenu.classList.remove('active');
        this.navToggle.classList.remove('active');
        
        // Restore body scroll
        document.body.style.overflow = 'auto';
        
        // Reset animation delays
        this.navLinks.forEach(link => {
            link.parentElement.style.animationDelay = '0s';
        });
    }
    
    handleScroll() {
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        
        // Add/remove scrolled class based on scroll position
        if (scrollTop > 100) {
            this.navbar.classList.add('scrolled');
        } else {
            this.navbar.classList.remove('scrolled');
        }
    }
    
    addLoadingAnimation() {
        // Add subtle entrance animation
        setTimeout(() => {
            this.navbar.style.opacity = '1';
        }, 100);
    }
}

// Smooth scrolling for anchor links
class SmoothScroll {
    constructor() {
        this.init();
    }
    
    init() {
        // Handle smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', (e) => {
                const href = anchor.getAttribute('href');
                
                // Skip if it's just '#'
                if (href === '#') {
                    e.preventDefault();
                    return;
                }
                
                const target = document.querySelector(href);
                
                if (target) {
                    e.preventDefault();
                    
                    const headerOffset = 80; // Navbar height
                    const elementPosition = target.getBoundingClientRect().top;
                    const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
                    
                    window.scrollTo({
                        top: offsetPosition,
                        behavior: 'smooth'
                    });
                }
            });
        });
    }
}

// Performance optimization
class PerformanceOptimizer {
    constructor() {
        this.init();
    }
    
    init() {
        // Throttle scroll events for better performance
        this.throttledScroll = this.throttle(() => {
            // Any scroll-based operations can be added here
        }, 16); // 60fps
        
        window.addEventListener('scroll', this.throttledScroll);
    }
    
    throttle(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
}

// Initialize everything when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Initialize navbar
    new ModernNavbar();
    
    // Initialize smooth scrolling
    new SmoothScroll();
    
    // Initialize performance optimizations
    new PerformanceOptimizer();
    
    // Initialize Gallery Manager
    galleryManager = new GalleryManager();
    
    // Initialize Lightbox Manager
    lightboxManager = new LightboxManager();
    // Make it globally accessible
    window.lightboxManager = lightboxManager;
    
    // Add page load animation
    document.body.classList.add('loaded');
    
    console.log('🎨 ArtGallery navigation system loaded successfully!');
});

// Handle page visibility changes for performance
document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
        // Pause any animations or heavy operations when tab is not visible
        console.log('🔇 Page hidden - optimizing performance');
    } else {
        // Resume operations when tab becomes visible
        console.log('🔊 Page visible - resuming normal operations');
    }
});



// Gallery and Masonry Layout Manager
class GalleryManager {
    constructor() {
        this.galleryContainer = document.getElementById('gallery');
        this.masonryInstance = null;
        this.init();
    }

    init() {
        if (!this.galleryContainer) {
            console.warn('Gallery container not found');
            return;
        }
        
        this.fetchAndDisplayArtworks();
    }

    // Fetch data from Firestore with error handling
    async fetchAndDisplayArtworks() {
        try {
            console.log('🎨 Fetching artworks from Firestore...');
            const querySnapshot = await getDocs(collection(db, "artGallery"));
            
            if (querySnapshot.empty) {
                console.log('No artworks found in database');
                this.showEmptyState();
                return;
            }

            querySnapshot.forEach((doc) => {
                const data = doc.data();
                console.log(`📄 Processing document: ${doc.id}`, data);
                
                let imagesFound = 0;
                
                // Process each field in the document
                Object.keys(data).forEach(key => {
                    console.log(`🔍 Checking field: ${key} = ${data[key]}`);
                    
                    // Check for image URLs - specifically optimized for your history1, history2, etc. pattern
                    const isHistoryField = key.startsWith('history');
                    const isOtherImageField = key === 'feature' || key === 'imageUrl' || key === 'url' || key === 'image';
                    
                    if (isHistoryField || isOtherImageField) {
                        console.log(`✅ Found potential image field: ${key}`);
                        
                        if (this.isValidImageUrl(data[key])) {
                            console.log(`🎨 Adding image to gallery: ${key} -> ${data[key]}`);
                            this.addImageToGallery(data[key], doc.id, key);
                            imagesFound++;
                        } else {
                            console.log(`❌ Invalid image URL for ${key}: ${data[key]}`);
                        }
                    } else {
                        console.log(`⏭️  Skipping non-image field: ${key}`);
                    }
                });
                
                console.log(`📊 Total images found in document ${doc.id}: ${imagesFound}`);
            });
            
            const totalImages = this.galleryContainer.children.length;
            console.log(`🖼️ Total images added to gallery: ${totalImages}`);
            
            if (totalImages === 0) {
                console.warn('⚠️ No images were added to the gallery. Check your Firebase data and URLs.');
                this.showEmptyState();
                return;
            }

            // Initialize Masonry after images are added
            this.initializeMasonry();
            
        } catch (error) {
            console.error("Error fetching art gallery data:", error);
            this.showErrorState();
        }
    }

    // Add image to gallery with proper error handling
    addImageToGallery(imageUrl, docId, fieldName) {
        const item = document.createElement('div');
        item.className = 'grid-item'; // ✅ FIXED: Proper property assignment
        item.setAttribute('data-doc-id', docId);
        item.setAttribute('data-field', fieldName);
        
        const img = document.createElement('img');
        img.src = imageUrl;
        img.alt = `Artwork from ${docId}`;
        img.loading = 'lazy'; // Performance optimization
        
        // Add loading state
        item.classList.add('loading');
        
        // Handle image load success
        img.onload = () => {
            item.classList.remove('loading');
            item.classList.add('loaded');
            // Relayout masonry when image loads
            if (this.masonryInstance) {
                this.masonryInstance.layout();
            }
        };
        
        // Handle image load error
        img.onerror = () => {
            item.classList.remove('loading');
            item.classList.add('error');
            img.src = this.getPlaceholderImage();
            console.warn(`Failed to load image: ${imageUrl}`);
        };
        
        item.appendChild(img);
        this.galleryContainer.appendChild(item);
    }

    // Initialize Masonry layout
    initializeMasonry() {
        if (typeof Masonry === 'undefined') {
            console.error('❌ Masonry library not loaded!');
            return;
        }
        
        if (typeof imagesLoaded === 'undefined') {
            console.error('❌ imagesLoaded library not loaded!');
            return;
        }
        
        // Initialize Masonry first
        this.masonryInstance = new Masonry(this.galleryContainer, {
            itemSelector: '.grid-item',
            columnWidth: '.grid-item',
            percentPosition: true,
            gutter: 20,
            fitWidth: true,
            transitionDuration: '0.3s'
        });
        
        console.log('🎨 Masonry initialized, waiting for images to load...');
        
        // Wait for images to load before laying out
        imagesLoaded(this.galleryContainer, () => {
            console.log('✅ All images loaded, laying out Masonry!');
            this.masonryInstance.layout();
            // Add lightbox click handlers after masonry is ready
            this.addLightboxHandlers();
        });
    }

    // Validate if URL is a valid image URL
    isValidImageUrl(url) {
        if (!url || typeof url !== 'string') return false;
        
        // Check for common image file extensions
        const hasImageExtension = url.match(/\.(jpeg|jpg|gif|png|svg|webp|bmp)$/i);
        
        // Check for known image hosting services
        const isImageService = url.includes('firebase') || 
                              url.includes('cloudinary') ||
                              url.includes('unsplash.com') ||
                              url.includes('images.unsplash.com') ||
                              url.includes('imgur.com') ||
                              url.includes('pixabay.com') ||
                              url.startsWith('data:image/');
        
        // For Unsplash URLs, they often have query parameters, so we check the domain
        const isUnsplashUrl = url.includes('unsplash.com') || url.includes('images.unsplash.com');
        
        return hasImageExtension || isImageService || isUnsplashUrl;
    }

    // Add click event handlers for lightbox functionality
    addLightboxHandlers() {
        const galleryItems = document.querySelectorAll('.grid-item');
        
        galleryItems.forEach(item => {
            // Remove any existing click handlers to avoid duplicates
            item.removeEventListener('click', this.handleImageClick);
            
            // Add click handler
            item.addEventListener('click', (e) => {
                e.preventDefault();
                
                // Don't open lightbox for error images
                if (item.classList.contains('error')) {
                    return;
                }
                
                // Open lightbox with clicked image
                if (window.lightboxManager) {
                    window.lightboxManager.open(e.target);
                }
            });
            
            // Add cursor pointer for non-error images
            if (!item.classList.contains('error')) {
                item.style.cursor = 'zoom-in';
            }
        });
        
        console.log(`🖱️ Added lightbox click handlers to ${galleryItems.length} gallery items`);
    }

    // Get placeholder image for failed loads
    getPlaceholderImage() {
        return 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgdmlld0JveD0iMCAwIDIwMCAyMDAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSIyMDAiIGhlaWdodD0iMjAwIiBmaWxsPSIjRjNGNEY2Ii8+CjxwYXRoIGQ9Ik02MCA2MEM2MCA1NS41ODE3IDYzLjU4MTcgNTIgNjggNTJIMTMyQzEzNi40MTggNTIgMTQwIDU1LjU4MTcgMTQwIDYwVjE0MEMxNDAgMTQ0LjQxOCAxMzYuNDE4IDE0OCAxMzIgMTQ4SDY4QzYzLjU4MTcgMTQ4IDYwIDE0NC40MTggNjAgMTQwVjYwWiIgc3Ryb2tlPSIjOUM5Qzk3IiBzdHJva2Utd2lkdGg9IjIiLz4KPHBhdGggZD0iTTc2IDg0QzgyLjYyNzQgODQgODggNzguNjI3NCA4OCA3MkM4OCA2NS4zNzI2IDgyLjYyNzQgNjAgNzYgNjBDNjkuMzcyNiA2MCA2NCA2NS4zNzI2IDY0IDcyQzY0IDc4LjYyNzQgNjkuMzcyNiA4NCA3NiA4NFoiIGZpbGw9IiM5QzlDOTciLz4KPHBhdGggZD0iTTEyNCAzNkw2OCA5Nkw4OC44IDExNi44TDEyNCAxMDBMMTU2IDEzNlYzNkgxMjRaIiBmaWxsPSIjOUM5Qzk3Ii8+Cjwvc3ZnPgo=';
    }

    // Show empty state when no artworks found - Load famous antique artworks instead
    showEmptyState() {
        console.log('📚 Loading famous antique artworks as fallback content...');
        
        // Load famous antique artworks
        FAMOUS_ANTIQUE_ARTWORKS.forEach((artwork, index) => {
            this.addAntiqueImageToGallery(artwork, `artwork-${index + 1}`);
        });
        
        // Initialize Masonry after adding fallback content
        setTimeout(() => {
            this.initializeMasonry();
        }, 100);
    }
    
    // Add famous antique artwork to gallery
    addAntiqueImageToGallery(artwork, itemId) {
        const item = document.createElement('div');
        item.className = 'grid-item';
        item.setAttribute('data-doc-id', itemId);
        item.setAttribute('data-field', 'antique-artwork');
        item.setAttribute('data-title', artwork.title);
        item.setAttribute('data-artist', artwork.artist);
        item.setAttribute('data-year', artwork.year);
        item.setAttribute('data-period', artwork.period);
        item.setAttribute('data-history', artwork.history);
        
        const img = document.createElement('img');
        img.src = artwork.url;
        img.alt = `${artwork.title} by ${artwork.artist} (${artwork.year})`;
        img.loading = 'lazy';
        
        // Add loading state
        item.classList.add('loading');
        
        // Handle image load success
        img.onload = () => {
            item.classList.remove('loading');
            item.classList.add('loaded');
            if (this.masonryInstance) {
                this.masonryInstance.layout();
            }
        };
        
        // Handle image load error
        img.onerror = () => {
            item.classList.remove('loading');
            item.classList.add('error');
            img.src = this.getPlaceholderImage();
            console.warn(`Failed to load famous artwork image: ${artwork.url}`);
        };
        
        item.appendChild(img);
        this.galleryContainer.appendChild(item);
    }

    // Show error state when fetch fails
    showErrorState() {
        this.galleryContainer.innerHTML = `
            <div class="error-state">
                <i class="fas fa-exclamation-triangle"></i>
                <h3>Failed to Load Gallery</h3>
                <p>Please check your internet connection and try again.</p>
                <button onclick="location.reload()" class="retry-btn">Retry</button>
            </div>
        `;
    }
}

// Initialize Gallery Manager
let galleryManager = null;

// Famous Antique Artworks Dataset with Historical Analysis
const FAMOUS_ANTIQUE_ARTWORKS = [
    {
        title: "The Starry Night",
        artist: "Vincent van Gogh",
        year: "1889",
        period: "Post-Impressionism",
        url: "https://images.unsplash.com/photo-1541961017774-22349e4a1262?w=800&q=80",
        history: "Painted during van Gogh's stay at the Saint-Paul-de-Mausole asylum, this masterpiece revolutionized artistic expression through its swirling, dynamic sky and emotional intensity. The painting represents the transition from Impressionism to modern art, showcasing van Gogh's unique vision of nature and his struggle with mental illness."
    },
    {
        title: "Girl with a Pearl Earring",
        artist: "Johannes Vermeer",
        year: "c. 1665",
        period: "Dutch Golden Age",
        url: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800&q=80",
        history: "Created during the height of the Dutch Golden Age, this intimate portrait exemplifies Vermeer's mastery of light and domestic scenes. The mysterious subject and luminous pearl reflect the prosperity of 17th-century Netherlands and the artist's innovative use of ultramarine pigment, then more valuable than gold."
    },
    {
        title: "The Great Wave off Kanagawa",
        artist: "Hokusai",
        year: "c. 1831",
        period: "Edo period",
        url: "https://images.unsplash.com/photo-1594736797933-d0f06ba09dbf?w=800&q=80",
        history: "Part of Hokusai's 'Thirty-six Views of Mount Fuji' series, this woodblock print captures the power of nature during Japan's Edo period. The artwork symbolizes the relationship between humanity and natural forces, influencing Western Impressionists and becoming an icon of Japanese artistic heritage worldwide."
    },
    {
        title: "American Gothic",
        artist: "Grant Wood",
        year: "1930",
        period: "Regionalism",
        url: "https://images.unsplash.com/photo-1578321272176-b7bbc0679853?w=800&q=80",
        history: "Painted during the Great Depression, this work represents American Regionalism's response to European modernism. Wood depicted rural Midwestern values and the stoic resilience of American farmers, creating an enduring symbol of American identity and work ethic during challenging economic times."
    },
    {
        title: "The Birth of Venus",
        artist: "Sandro Botticelli",
        year: "c. 1484-1486",
        period: "Renaissance",
        url: "https://images.unsplash.com/photo-1594841962696-97d8b2735701?w=800&q=80",
        history: "Commissioned during the height of the Italian Renaissance, this masterpiece embodies Humanist philosophy and the revival of classical mythology. Painted for the Medici family, it represents the union of Christian and pagan ideals, showcasing the period's celebration of beauty, love, and divine femininity."
    },
    {
        title: "Las Meninas",
        artist: "Diego Velázquez",
        year: "1656",
        period: "Spanish Golden Age",
        url: "https://images.unsplash.com/photo-1580927752452-89d86da3fa0a?w=800&q=80",
        history: "Created in the royal court of Philip IV, this complex composition revolutionized perspective and reality in art. Velázquez painted himself into the scene, creating a meta-artistic commentary on the nature of painting and royal power during Spain's cultural zenith, influencing centuries of artists including Manet and Picasso."
    },
    {
        title: "The Scream",
        artist: "Edvard Munch",
        year: "1893",
        period: "Expressionism",
        url: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=600&q=80",
        history: "Born from Munch's personal experience of anxiety and existential dread, this iconic work became the defining image of modern psychological angst. Created during the fin de siècle period, it reflects the anxieties of industrial society and pioneered Expressionism's focus on emotional rather than physical reality."
    },
    {
        title: "Liberty Leading the People",
        artist: "Eugène Delacroix",
        year: "1830",
        period: "Romanticism",
        url: "https://images.unsplash.com/photo-1578321272176-b7bbc0679853?w=600&q=80",
        history: "Painted in response to the July Revolution of 1830, this masterpiece embodies Romantic ideals of political freedom and popular uprising. Delacroix combined classical allegory with contemporary events, creating a powerful symbol of democratic revolution that influenced political art and became France's national symbol of liberty."
    },
    {
        title: "The Kiss",
        artist: "Gustav Klimt",
        year: "1907-1908",
        period: "Art Nouveau",
        url: "https://images.unsplash.com/photo-1594841962696-97d8b2735701?w=600&q=80",
        history: "Created during Klimt's 'Golden Period' in Vienna, this work epitomizes Art Nouveau's decorative style and the city's cultural renaissance. The painting reflects the era's fascination with love, sexuality, and psychological symbolism, challenging Victorian moral constraints while celebrating human intimacy through Byzantine-inspired golden patterns."
    },
    {
        title: "A Sunday on La Grande Jatte",
        artist: "Georges Seurat",
        year: "1884-1886",
        period: "Neo-Impressionism",
        url: "https://images.unsplash.com/photo-1580927752452-89d86da3fa0a?w=600&q=80",
        history: "Revolutionary in its scientific approach to color, this pointillist masterpiece took two years to complete using thousands of tiny dots. Seurat applied color theory and optics to capture modern Parisian leisure, creating a timeless scene that bridges Impressionism and modern art while commenting on class structure in industrial society."
    },
    {
        title: "The Persistence of Memory",
        artist: "Salvador Dalí",
        year: "1931",
        period: "Surrealism",
        url: "https://images.unsplash.com/photo-1594736797933-d0f06ba09dbf?w=600&q=80",
        history: "Inspired by Einstein's theory of relativity and Freudian psychoanalysis, this surrealist icon challenges our perception of time and reality. Painted during the interwar period, it reflects the era's scientific discoveries and psychological explorations, using dreamlike imagery to explore the subconscious mind and the fluid nature of time."
    },
    {
        title: "Guernica",
        artist: "Pablo Picasso",
        year: "1937",
        period: "Cubism",
        url: "https://images.unsplash.com/photo-1541961017774-22349e4a1262?w=600&q=80",
        history: "Commissioned for the Spanish Pavilion at the 1937 Paris Exposition, this monumental work responds to the bombing of Guernica during the Spanish Civil War. Picasso's fragmented, cubist style powerfully conveys the horror of modern warfare, making it one of the most influential anti-war artworks and a symbol of peace movements worldwide."
    },
    {
        title: "Mona Lisa",
        artist: "Leonardo da Vinci",
        year: "1503-1519",
        period: "High Renaissance",
        url: "https://images.unsplash.com/photo-1578321272176-b7bbc0679853?w=700&q=80",
        history: "Perhaps the world's most famous painting, this portrait exemplifies Renaissance humanism and Leonardo's scientific approach to art. The enigmatic smile and sfumato technique represent the peak of Renaissance portraiture, while the painting's theft in 1911 cemented its status as a global cultural icon."
    },
    {
        title: "The Creation of Adam",
        artist: "Michelangelo",
        year: "1508-1512",
        period: "High Renaissance",
        url: "https://images.unsplash.com/photo-1594841962696-97d8b2735701?w=700&q=80",
        history: "Part of the Sistine Chapel ceiling, this fresco represents the pinnacle of Renaissance art and humanist philosophy. Commissioned by Pope Julius II, it depicts the biblical creation story while showcasing Michelangelo's mastery of human anatomy and his revolutionary ceiling painting techniques that influenced Western art for centuries."
    },
    {
        title: "Water Lilies",
        artist: "Claude Monet",
        year: "1914-1926",
        period: "Impressionism",
        url: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=700&q=80",
        history: "Created in Monet's garden at Giverny, this series marks the culmination of Impressionism and the birth of abstract art. Painted during World War I, these large-scale canvases reflect Monet's lifelong study of light and color, serving as both a meditation on nature and an escape from the turmoil of war."
    },
    {
        title: "The Night Watch",
        artist: "Rembrandt van Rijn",
        year: "1642",
        period: "Dutch Golden Age",
        url: "https://images.unsplash.com/photo-1580927752452-89d86da3fa0a?w=700&q=80",
        history: "Commissioned by Amsterdam's civic guard, this masterpiece revolutionized group portraiture by depicting subjects in motion rather than static poses. Created during the height of Dutch prosperity, it showcases Rembrandt's innovative use of light and shadow while documenting the social and military structures of 17th-century Netherlands."
    },
    {
        title: "The Last Supper",
        artist: "Leonardo da Vinci",
        year: "1495-1498",
        period: "High Renaissance",
        url: "https://images.unsplash.com/photo-1541961017774-22349e4a1262?w=700&q=80",
        history: "Painted on the wall of Milan's Santa Maria delle Grazie convent, this mural depicts the pivotal biblical moment when Jesus announces his betrayal. Leonardo's experimental techniques and psychological depth in portraying each apostle's reaction created a template for narrative painting that influenced religious art for centuries."
    },
    {
        title: "Café Terrace at Night",
        artist: "Vincent van Gogh",
        year: "1888",
        period: "Post-Impressionism",
        url: "https://images.unsplash.com/photo-1594736797933-d0f06ba09dbf?w=700&q=80",
        history: "Van Gogh's first painting to feature his signature starry sky, created during his productive period in Arles. This nocturne demonstrates his fascination with the contrast between artificial and natural light, painted outdoors at night, which was revolutionary for the time and showcases his bold use of complementary colors."
    },
    {
        title: "Composition VII",
        artist: "Wassily Kandinsky",
        year: "1913",
        period: "Abstract Expressionism",
        url: "https://images.unsplash.com/photo-1578321272176-b7bbc0679853?w=700&q=80",
        history: "Considered one of the first purely abstract paintings, this work represents Kandinsky's theory of spiritual abstraction and synesthesia. Created on the eve of World War I, it abandons representational art entirely, using color and form to express inner emotions and spiritual experiences, founding the abstract art movement."
    },
    {
        title: "The Son of Man",
        artist: "René Magritte",
        year: "1964",
        period: "Surrealism",
        url: "https://images.unsplash.com/photo-1594841962696-97d8b2735701?w=700&q=80",
        history: "This enigmatic self-portrait epitomizes Magritte's exploration of visible and hidden reality. The apple obscuring the man's face questions the nature of identity and perception, reflecting post-war existential anxieties and the artist's lifelong investigation into the relationship between image and meaning."
    },
    {
        title: "Dogs Playing Poker",
        artist: "C.M. Coolidge",
        year: "1903",
        period: "American Popular Art",
        url: "https://images.unsplash.com/photo-1580927752452-89d86da3fa0a?w=700&q=80",
        history: "This series of paintings became iconic in American popular culture, representing the democratization of art in the early 20th century. Originally commissioned for advertising, these works reflect American humor and the growing middle-class leisure culture, becoming symbols of kitsch art and Americana."
    },
    {
        title: "Campbell's Soup Cans",
        artist: "Andy Warhol",
        year: "1962",
        period: "Pop Art",
        url: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=700&q=80",
        history: "Warhol's breakthrough work launched Pop Art by elevating everyday consumer products to fine art status. Created during America's consumer boom, these silkscreens challenged traditional art hierarchies and reflected the mass production culture of the 1960s, questioning the nature of art in a commercialized society."
    },
    {
        title: "The Thinker",
        artist: "Auguste Rodin",
        year: "1904",
        period: "Modern Sculpture",
        url: "https://images.unsplash.com/photo-1541961017774-22349e4a1262?w=700&q=80",
        history: "Originally part of 'The Gates of Hell', this bronze sculpture became an independent icon of human contemplation and philosophy. Created during the industrial age, it represents man's intellectual struggle and has become a universal symbol of thinking and creativity, influencing modern sculpture worldwide."
    },
    {
        title: "Woman with a Parasol",
        artist: "Claude Monet",
        year: "1875",
        period: "Impressionism",
        url: "https://images.unsplash.com/photo-1594736797933-d0f06ba09dbf?w=700&q=80",
        history: "This plein air painting of Monet's wife and son captures a fleeting moment in time, embodying the Impressionist movement's core principles. Painted quickly outdoors, it demonstrates the revolutionary technique of capturing light and atmosphere rather than precise details, helping establish Impressionism as a legitimate artistic movement."
    },
    {
        title: "The Arnolfini Portrait",
        artist: "Jan van Eyck",
        year: "1434",
        period: "Northern Renaissance",
        url: "https://images.unsplash.com/photo-1580927752452-89d86da3fa0a?w=700&q=80",
        history: "This oil painting revolutionized portraiture through its photographic realism and symbolic complexity. Created during the Northern Renaissance, it showcases van Eyck's mastery of oil painting and hidden symbolism, documenting the wealth and domestic life of 15th-century Flemish merchants while pushing the boundaries of artistic realism."
    },
    {
        title: "The Dance",
        artist: "Henri Matisse",
        year: "1910",
        period: "Fauvism",
        url: "https://images.unsplash.com/photo-1578321272176-b7bbc0679853?w=700&q=80",
        history: "This bold composition exemplifies Fauvism's revolutionary use of color and simplified forms. Commissioned by Russian collector Sergei Shchukin, it represents primitive energy and joy through pure color and movement, influencing modern art's departure from naturalistic representation toward emotional expression."
    },
    {
        title: "Washington Crossing the Delaware",
        artist: "Emanuel Leutze",
        year: "1851",
        period: "American Romanticism",
        url: "https://images.unsplash.com/photo-1594841962696-97d8b2735701?w=700&q=80",
        history: "Painted in Düsseldorf by a German-American artist, this work became an icon of American courage and determination. Created during a period of European political upheaval, it romanticizes the American Revolution while serving as inspiration for 19th-century democratic movements, despite its historical inaccuracies."
    },
    {
        title: "The Card Players",
        artist: "Paul Cézanne",
        year: "1890-1895",
        period: "Post-Impressionism",
        url: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=700&q=80",
        history: "This series represents Cézanne's mature style that bridged Impressionism and Cubism. Painted in rural Provence, these works strip away narrative to focus on form and structure, influencing the development of modern art through their emphasis on geometric simplification and compositional harmony."
    },
    {
        title: "The Weeping Woman",
        artist: "Pablo Picasso",
        year: "1937",
        period: "Cubism",
        url: "https://images.unsplash.com/photo-1580927752452-89d86da3fa0a?w=700&q=80",
        history: "Created during the Spanish Civil War as a companion to Guernica, this portrait embodies human suffering through Cubist fragmentation. The work reflects Picasso's emotional response to war and his relationship with photographer Dora Maar, combining personal and political themes through revolutionary artistic techniques."
    },
    {
        title: "Nighthawks",
        artist: "Edward Hopper",
        year: "1942",
        period: "American Realism",
        url: "https://images.unsplash.com/photo-1541961017774-22349e4a1262?w=700&q=80",
        history: "Painted during World War II, this nocturnal scene captures urban isolation and the American psyche during wartime. Hopper's masterpiece reflects 1940s urban life and the existential loneliness of modern society, becoming an enduring symbol of American solitude and the film noir aesthetic."
    }
];


// ========================================
// LIGHTBOX FUNCTIONALITY
// ========================================

class LightboxManager {
    constructor() {
        this.lightbox = document.getElementById('lightbox');
        this.lightboxImage = document.getElementById('lightbox-image');
        this.lightboxTitle = document.getElementById('lightbox-title');
        this.lightboxDescription = document.getElementById('lightbox-description');
        this.lightboxCurrent = document.getElementById('lightbox-current');
        this.lightboxTotal = document.getElementById('lightbox-total');
        this.lightboxLoading = document.querySelector('.lightbox-loading');
        
        this.closeBtn = document.querySelector('.lightbox-close');
        this.prevBtn = document.querySelector('.lightbox-prev');
        this.nextBtn = document.querySelector('.lightbox-next');
        this.overlay = document.querySelector('.lightbox-overlay');
        
        this.images = [];
        this.currentIndex = 0;
        this.isOpen = false;
        
        this.init();
    }
    
    init() {
        this.bindEvents();
        console.log('🔍 Lightbox Manager initialized');
    }
    
    bindEvents() {
        // Close lightbox events
        this.closeBtn?.addEventListener('click', () => this.close());
        this.overlay?.addEventListener('click', () => this.close());
        
        // Navigation events
        this.prevBtn?.addEventListener('click', () => this.showPrevious());
        this.nextBtn?.addEventListener('click', () => this.showNext());
        
        // Keyboard navigation
        document.addEventListener('keydown', (e) => {
            if (!this.isOpen) return;
            
            switch(e.key) {
                case 'Escape':
                    this.close();
                    break;
                case 'ArrowLeft':
                    this.showPrevious();
                    break;
                case 'ArrowRight':
                    this.showNext();
                    break;
            }
        });
        
        // Prevent propagation on lightbox content
        document.querySelector('.lightbox-content')?.addEventListener('click', (e) => {
            e.stopPropagation();
        });
    }
    
    // Update image list from gallery
    updateImageList() {
        const galleryItems = document.querySelectorAll('.grid-item');
        this.images = [];
        
        galleryItems.forEach((item, index) => {
            const img = item.querySelector('img');
            if (img && !item.classList.contains('error')) {
                this.images.push({
                    src: img.src,
                    alt: img.alt,
                    title: this.generateTitle(item),
                    description: this.generateDescription(item),
                    element: item,
                    index: index
                });
            }
        });
        
        console.log(`📸 Updated lightbox with ${this.images.length} images`);
    }
    
    // Generate title for image
    generateTitle(item) {
        const docId = item.getAttribute('data-doc-id');
        const fieldName = item.getAttribute('data-field');
        
        // Check if it's a famous antique artwork
        if (fieldName === 'antique-artwork') {
            const title = item.getAttribute('data-title');
            const artist = item.getAttribute('data-artist');
            const year = item.getAttribute('data-year');
            
            if (title && artist && year) {
                return `${title} by ${artist} (${year})`;
            }
        }
        
        if (fieldName && fieldName.startsWith('history')) {
            return `Historical Artwork`; // Remove numbering
        }
        
        return `Artwork from ${docId || 'Collection'}`;
    }
    
    // Generate description for image - Enhanced with historical analysis
    generateDescription(item) {
        const docId = item.getAttribute('data-doc-id');
        const fieldName = item.getAttribute('data-field');
        
        // Check if it's a famous antique artwork with historical data
        if (fieldName === 'antique-artwork') {
            const history = item.getAttribute('data-history');
            const period = item.getAttribute('data-period');
            
            if (history) {
                return history; // Return the detailed historical analysis
            } else if (period) {
                return `A masterpiece from the ${period} period, showcasing the artistic techniques and cultural values of its era.`;
            }
        }
        
        // For regular Firebase images, provide basic info
        if (fieldName && fieldName.startsWith('history')) {
            return `A historical artwork showcasing artistic techniques and cultural heritage from a significant period in art history.`;
        }
        
        return `An artwork from the gallery collection, representing unique artistic expression and creative vision.`;
    }
    
    // Open lightbox with specific image
    open(imageElement) {
        this.updateImageList();
        
        // Find the index of the clicked image
        const clickedItem = imageElement.closest('.grid-item');
        this.currentIndex = this.images.findIndex(img => img.element === clickedItem);
        
        if (this.currentIndex === -1) {
            console.warn('Image not found in lightbox collection');
            return;
        }
        
        this.isOpen = true;
        this.lightbox.classList.add('active');
        document.body.classList.add('lightbox-open');
        
        // Update navigation visibility
        if (this.images.length <= 1) {
            this.lightbox.classList.add('single-image');
        } else {
            this.lightbox.classList.remove('single-image');
        }
        
        this.showImage(this.currentIndex);
        
        console.log(`🖼️ Lightbox opened with image ${this.currentIndex + 1} of ${this.images.length}`);
    }
    
    // Show specific image
    showImage(index) {
        if (index < 0 || index >= this.images.length) return;
        
        this.currentIndex = index;
        const image = this.images[index];
        
        // Show loading state
        this.showLoading(true);
        
        // Update image
        this.lightboxImage.onload = () => {
            this.showLoading(false);
        };
        
        this.lightboxImage.onerror = () => {
            this.showLoading(false);
            console.warn('Failed to load lightbox image:', image.src);
        };
        
        this.lightboxImage.src = image.src;
        this.lightboxImage.alt = image.alt;
        
        // Update info
        this.lightboxTitle.textContent = image.title;
        this.lightboxDescription.textContent = image.description;
        this.lightboxCurrent.textContent = index + 1;
        this.lightboxTotal.textContent = this.images.length;
        
        // Update navigation state
        this.updateNavigationState();
    }
    
    // Show/hide loading state
    showLoading(show) {
        if (show) {
            this.lightboxLoading.classList.add('active');
        } else {
            this.lightboxLoading.classList.remove('active');
        }
    }
    
    // Update navigation button states
    updateNavigationState() {
        // For now, keep all buttons enabled as we can loop
        // You can modify this to disable at endpoints if preferred
    }
    
    // Show previous image
    showPrevious() {
        if (this.images.length <= 1) return;
        
        let newIndex = this.currentIndex - 1;
        if (newIndex < 0) {
            newIndex = this.images.length - 1; // Loop to last image
        }
        
        this.showImage(newIndex);
    }
    
    // Show next image
    showNext() {
        if (this.images.length <= 1) return;
        
        let newIndex = this.currentIndex + 1;
        if (newIndex >= this.images.length) {
            newIndex = 0; // Loop to first image
        }
        
        this.showImage(newIndex);
    }
    
    // Close lightbox
    close() {
        this.isOpen = false;
        this.lightbox.classList.remove('active');
        document.body.classList.remove('lightbox-open');
        
        // Reset image source to prevent flashing
        setTimeout(() => {
            if (!this.isOpen) {
                this.lightboxImage.src = '';
            }
        }, 300);
        
        console.log('❌ Lightbox closed');
    }
}

// Initialize Lightbox Manager
let lightboxManager = null;
