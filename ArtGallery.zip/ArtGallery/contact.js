// Contact page JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Form validation and submission
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        setupFormValidation();
        setupFormSubmission();
    }

    // Setup form validation
    function setupFormValidation() {
        const formInputs = contactForm.querySelectorAll('input, select, textarea');
        
        formInputs.forEach(input => {
            // Real-time validation
            input.addEventListener('blur', function() {
                validateField(this);
            });

            input.addEventListener('input', function() {
                // Remove error state on input
                removeErrorState(this);
            });
        });

        // Form submission validation
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            let isValid = true;
            formInputs.forEach(input => {
                if (!validateField(input)) {
                    isValid = false;
                }
            });

            if (isValid) {
                submitForm();
            } else {
                ArtGalleryUtils.showNotification('Please fix the errors in the form', 'error');
                
                // Focus on first error field
                const firstError = contactForm.querySelector('.form-group.error input, .form-group.error select, .form-group.error textarea');
                if (firstError) {
                    firstError.focus();
                }
            }
        });
    }

    // Validate individual field
    function validateField(field) {
        const value = field.value.trim();
        const fieldName = field.name;
        const formGroup = field.closest('.form-group');
        
        // Remove previous error state
        removeErrorState(field);
        
        // Check if required field is empty
        if (field.required && !value) {
            showFieldError(field, `${getFieldDisplayName(fieldName)} is required`);
            return false;
        }

        // Email validation
        if (fieldName === 'email' && value) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(value)) {
                showFieldError(field, 'Please enter a valid email address');
                return false;
            }
        }

        // Phone validation (optional but must be valid if provided)
        if (fieldName === 'phone' && value) {
            const phoneRegex = /^[\+]?[1-9][\d]{0,15}$/;
            if (!phoneRegex.test(value.replace(/[\s\-\(\)]/g, ''))) {
                showFieldError(field, 'Please enter a valid phone number');
                return false;
            }
        }

        // Message minimum length
        if (fieldName === 'message' && value && value.length < 10) {
            showFieldError(field, 'Message must be at least 10 characters long');
            return false;
        }

        // Name validation (letters, spaces, hyphens, apostrophes only)
        if ((fieldName === 'firstName' || fieldName === 'lastName') && value) {
            const nameRegex = /^[a-zA-Z\s\-']+$/;
            if (!nameRegex.test(value)) {
                showFieldError(field, 'Please enter a valid name (letters only)');
                return false;
            }
        }

        return true;
    }

    // Show field error
    function showFieldError(field, message) {
        const formGroup = field.closest('.form-group');
        formGroup.classList.add('error');
        
        // Remove existing error message
        const existingError = formGroup.querySelector('.error-message');
        if (existingError) {
            existingError.remove();
        }
        
        // Add new error message
        const errorMessage = document.createElement('div');
        errorMessage.className = 'error-message';
        errorMessage.textContent = message;
        formGroup.appendChild(errorMessage);
        
        // Add error styles if not already added
        addFormErrorStyles();
    }

    // Remove field error state
    function removeErrorState(field) {
        const formGroup = field.closest('.form-group');
        formGroup.classList.remove('error');
        
        const errorMessage = formGroup.querySelector('.error-message');
        if (errorMessage) {
            errorMessage.remove();
        }
    }

    // Get display name for field
    function getFieldDisplayName(fieldName) {
        const displayNames = {
            firstName: 'First Name',
            lastName: 'Last Name',
            email: 'Email Address',
            phone: 'Phone Number',
            subject: 'Subject',
            message: 'Message'
        };
        return displayNames[fieldName] || fieldName;
    }

    // Add form error styles
    function addFormErrorStyles() {
        if (!document.getElementById('form-error-styles')) {
            const style = document.createElement('style');
            style.id = 'form-error-styles';
            style.textContent = `
                .form-group.error input,
                .form-group.error select,
                .form-group.error textarea {
                    border-color: #EF4444;
                    box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.1);
                }
                
                .error-message {
                    color: #EF4444;
                    font-size: 0.875rem;
                    margin-top: 0.5rem;
                    display: flex;
                    align-items: center;
                    gap: 0.25rem;
                }
                
                .error-message::before {
                    content: "⚠";
                    font-size: 0.75rem;
                }
                
                .form-group.error label {
                    color: #EF4444;
                }
            `;
            document.head.appendChild(style);
        }
    }

    // Setup form submission
    function setupFormSubmission() {
        // In a real application, you would submit to a server
        // For this demo, we'll simulate a successful submission
    }

    // Submit form
    function submitForm() {
        const submitButton = contactForm.querySelector('button[type="submit"]');
        const originalContent = ArtGalleryUtils.showLoading(submitButton, 'Sending...');
        
        // Collect form data
        const formData = new FormData(contactForm);
        const data = Object.fromEntries(formData);
        
        // Simulate API call
        setTimeout(() => {
            // In a real application, you would make an actual API call here
            try {
                // Simulate successful submission
                console.log('Form submitted:', data);
                
                ArtGalleryUtils.hideLoading(submitButton, originalContent);
                ArtGalleryUtils.showNotification('Thank you for your message! We\'ll get back to you soon.', 'success');
                
                // Reset form
                contactForm.reset();
                
                // Optional: Send confirmation email or show success page
                showSuccessMessage();
                
            } catch (error) {
                ArtGalleryUtils.hideLoading(submitButton, originalContent);
                ArtGalleryUtils.showNotification('Sorry, there was an error sending your message. Please try again.', 'error');
            }
        }, 2000); // Simulate network delay
    }

    // Show success message
    function showSuccessMessage() {
        // Create and show a success modal or replace form content
        const successMessage = document.createElement('div');
        successMessage.className = 'success-message';
        successMessage.innerHTML = `
            <div class="success-content">
                <div class="success-icon">
                    <i class="fas fa-check-circle"></i>
                </div>
                <h3>Message Sent Successfully!</h3>
                <p>Thank you for contacting us. We've received your message and will get back to you within 24 hours.</p>
                <button class="btn-primary" onclick="location.reload()">Send Another Message</button>
            </div>
        `;
        
        // Add success message styles
        if (!document.getElementById('success-message-styles')) {
            const style = document.createElement('style');
            style.id = 'success-message-styles';
            style.textContent = `
                .success-message {
                    background: white;
                    border-radius: 16px;
                    padding: 3rem;
                    text-align: center;
                    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
                    animation: fadeInUp 0.6s ease;
                }
                
                .success-icon {
                    width: 80px;
                    height: 80px;
                    background: linear-gradient(135deg, #10B981, #059669);
                    border-radius: 50%;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    margin: 0 auto 2rem;
                }
                
                .success-icon i {
                    color: white;
                    font-size: 2rem;
                }
                
                .success-content h3 {
                    font-size: 2rem;
                    font-weight: 600;
                    color: var(--navbar-bg);
                    margin-bottom: 1rem;
                }
                
                .success-content p {
                    color: var(--text-muted);
                    font-size: 1.1rem;
                    line-height: 1.6;
                    margin-bottom: 2rem;
                    max-width: 400px;
                    margin-left: auto;
                    margin-right: auto;
                }
            `;
            document.head.appendChild(style);
        }
        
        // Replace form with success message
        const formSection = document.querySelector('.contact-form-section');
        if (formSection) {
            formSection.innerHTML = '';
            formSection.appendChild(successMessage);
        }
    }

    // Auto-resize textarea
    const messageTextarea = document.getElementById('message');
    if (messageTextarea) {
        messageTextarea.addEventListener('input', function() {
            this.style.height = 'auto';
            this.style.height = (this.scrollHeight) + 'px';
        });
    }

    // Character counter for message field
    if (messageTextarea) {
        const maxLength = 1000;
        const counter = document.createElement('div');
        counter.className = 'character-counter';
        counter.textContent = `0/${maxLength} characters`;
        
        messageTextarea.setAttribute('maxlength', maxLength);
        messageTextarea.parentElement.appendChild(counter);
        
        messageTextarea.addEventListener('input', function() {
            const remaining = maxLength - this.value.length;
            counter.textContent = `${this.value.length}/${maxLength} characters`;
            
            if (remaining < 50) {
                counter.style.color = '#EF4444';
            } else {
                counter.style.color = 'var(--text-muted)';
            }
        });
        
        // Add counter styles
        if (!document.getElementById('counter-styles')) {
            const style = document.createElement('style');
            style.id = 'counter-styles';
            style.textContent = `
                .character-counter {
                    font-size: 0.875rem;
                    color: var(--text-muted);
                    text-align: right;
                    margin-top: 0.5rem;
                    transition: color 0.3s ease;
                }
            `;
            document.head.appendChild(style);
        }
    }

    // FAQ accordion functionality
    const faqItems = document.querySelectorAll('.faq-item');
    faqItems.forEach(item => {
        const question = item.querySelector('h3');
        if (question) {
            question.style.cursor = 'pointer';
            question.addEventListener('click', function() {
                const answer = item.querySelector('p');
                const isOpen = item.classList.contains('open');
                
                // Close all other items
                faqItems.forEach(otherItem => {
                    if (otherItem !== item) {
                        otherItem.classList.remove('open');
                        const otherAnswer = otherItem.querySelector('p');
                        if (otherAnswer) {
                            otherAnswer.style.maxHeight = '0';
                            otherAnswer.style.opacity = '0';
                        }
                    }
                });
                
                // Toggle current item
                if (isOpen) {
                    item.classList.remove('open');
                    answer.style.maxHeight = '0';
                    answer.style.opacity = '0';
                } else {
                    item.classList.add('open');
                    answer.style.maxHeight = answer.scrollHeight + 'px';
                    answer.style.opacity = '1';
                }
            });
        }
    });

    // Add FAQ accordion styles
    if (!document.getElementById('faq-accordion-styles')) {
        const style = document.createElement('style');
        style.id = 'faq-accordion-styles';
        style.textContent = `
            .faq-item h3 {
                position: relative;
                user-select: none;
                padding-right: 2rem;
            }
            
            .faq-item h3::after {
                content: '+';
                position: absolute;
                right: 0;
                top: 0;
                font-size: 1.5rem;
                font-weight: 300;
                transition: transform 0.3s ease;
                color: var(--accent-color);
            }
            
            .faq-item.open h3::after {
                transform: rotate(45deg);
            }
            
            .faq-item p {
                overflow: hidden;
                transition: max-height 0.3s ease, opacity 0.3s ease, padding-top 0.3s ease;
                max-height: 0;
                opacity: 0;
                padding-top: 0;
            }
            
            .faq-item.open p {
                padding-top: 1rem;
            }
        `;
        document.head.appendChild(style);
    }

    // Contact info card animations
    const contactCards = document.querySelectorAll('.contact-info-card');
    contactCards.forEach((card, index) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(30px)';
        card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        
        setTimeout(() => {
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, index * 150);
    });

    // Add loading state for map buttons
    document.querySelectorAll('.map-buttons .btn-secondary').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const originalContent = ArtGalleryUtils.showLoading(this, 'Opening...');
            
            setTimeout(() => {
                ArtGalleryUtils.hideLoading(this, originalContent);
                ArtGalleryUtils.showNotification('This would open the map application', 'info');
            }, 1000);
        });
    });

    // Form autosave (optional feature)
    let autosaveTimeout;
    const formInputs = contactForm ? contactForm.querySelectorAll('input, select, textarea') : [];
    
    formInputs.forEach(input => {
        input.addEventListener('input', function() {
            clearTimeout(autosaveTimeout);
            autosaveTimeout = setTimeout(() => {
                saveFormData();
            }, 2000);
        });
    });

    function saveFormData() {
        if (!contactForm) return;
        
        const formData = new FormData(contactForm);
        const data = Object.fromEntries(formData);
        
        // Save to localStorage for recovery
        localStorage.setItem('contactFormData', JSON.stringify(data));
    }

    function restoreFormData() {
        if (!contactForm) return;
        
        const savedData = localStorage.getItem('contactFormData');
        if (savedData) {
            try {
                const data = JSON.parse(savedData);
                Object.keys(data).forEach(key => {
                    const field = contactForm.querySelector(`[name="${key}"]`);
                    if (field && data[key]) {
                        field.value = data[key];
                    }
                });
            } catch (e) {
                console.log('Could not restore form data');
            }
        }
    }

    // Clear autosaved data on successful submission
    function clearFormData() {
        localStorage.removeItem('contactFormData');
    }

    // Restore form data on page load
    restoreFormData();
});

// Contact form utilities
window.ContactUtils = {
    // Validate email
    validateEmail: function(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    },
    
    // Format phone number
    formatPhone: function(phone) {
        const cleaned = phone.replace(/\D/g, '');
        const match = cleaned.match(/^(\d{3})(\d{3})(\d{4})$/);
        if (match) {
            return '(' + match[1] + ') ' + match[2] + '-' + match[3];
        }
        return phone;
    },
    
    // Copy text to clipboard
    copyToClipboard: function(text) {
        navigator.clipboard.writeText(text).then(() => {
            ArtGalleryUtils.showNotification('Copied to clipboard!', 'success', 2000);
        }).catch(() => {
            ArtGalleryUtils.showNotification('Could not copy to clipboard', 'error', 2000);
        });
    }
};
