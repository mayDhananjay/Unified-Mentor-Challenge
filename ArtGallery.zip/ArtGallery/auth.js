// Authentication module for ArtGallery
import { auth } from './firebaseScript.js';
import {
    createUserWithEmailAndPassword,
    signInWithEmailAndPassword,
    signOut,
    onAuthStateChanged,
    updateProfile
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-auth.js";

// ─── Auth State Observer ────────────────────────────────────────────────────

/**
 * Subscribes to Firebase auth state changes and calls the provided callback
 * with the current user (or null if signed out).
 *
 * @param {function(import("firebase/auth").User|null): void} callback
 * @returns {function} Unsubscribe function
 */
export function onAuthStateChange(callback) {
    return onAuthStateChanged(auth, callback);
}

// ─── Register ───────────────────────────────────────────────────────────────

/**
 * Creates a new user account with email, password and optional display name.
 *
 * @param {string} email
 * @param {string} password
 * @param {string} [displayName]
 * @returns {Promise<import("firebase/auth").UserCredential>}
 */
export async function registerUser(email, password, displayName) {
    const credential = await createUserWithEmailAndPassword(auth, email, password);
    if (displayName) {
        await updateProfile(credential.user, { displayName });
    }
    return credential;
}

// ─── Login ──────────────────────────────────────────────────────────────────

/**
 * Signs in an existing user with email and password.
 *
 * @param {string} email
 * @param {string} password
 * @returns {Promise<import("firebase/auth").UserCredential>}
 */
export async function loginUser(email, password) {
    return signInWithEmailAndPassword(auth, email, password);
}

// ─── Logout ─────────────────────────────────────────────────────────────────

/**
 * Signs out the currently authenticated user.
 *
 * @returns {Promise<void>}
 */
export async function logoutUser() {
    return signOut(auth);
}

// ─── Current User Helper ────────────────────────────────────────────────────

/**
 * Returns the currently signed-in user, or null.
 *
 * @returns {import("firebase/auth").User|null}
 */
export function getCurrentUser() {
    return auth.currentUser;
}

// ─── Human-readable Firebase error messages ─────────────────────────────────

const AUTH_ERROR_MESSAGES = {
    'auth/email-already-in-use':    'This email is already registered. Please log in instead.',
    'auth/invalid-email':           'Please enter a valid email address.',
    'auth/weak-password':           'Password must be at least 6 characters.',
    'auth/user-not-found':          'No account found for this email address.',
    'auth/wrong-password':          'Incorrect password. Please try again.',
    'auth/too-many-requests':       'Too many failed attempts. Please try again later.',
    'auth/network-request-failed':  'Network error. Please check your connection.',
    'auth/invalid-credential':      'Invalid email or password. Please try again.',
};

/**
 * Returns a user-friendly message for a Firebase Auth error.
 *
 * @param {import("firebase/auth").AuthError} error
 * @returns {string}
 */
export function getAuthErrorMessage(error) {
    return AUTH_ERROR_MESSAGES[error.code] || 'An unexpected error occurred. Please try again.';
}
