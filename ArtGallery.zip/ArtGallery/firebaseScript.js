// Import the functions you need from the SDKs you need
import { initializeApp } from "https://www.gstatic.com/firebasejs/12.0.0/firebase-app.js";
import { getAnalytics } from "https://www.gstatic.com/firebasejs/12.0.0/firebase-analytics.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyBIooeS7car_yKKDDOPKxsYGpPeeCE2u0E",
  authDomain: "mygal2.firebaseapp.com",
  projectId: "mygal2",
  storageBucket: "mygal2.firebasestorage.app",
  messagingSenderId: "197459581616",
  appId: "1:197459581616:web:037da905dad4fc5284f975",
  measurementId: "G-89E4GKS05C"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
const db = getFirestore(app);

// Export for use in other modules
export { db, analytics, app };

console.log('🔥 Firebase initialized successfully!');
