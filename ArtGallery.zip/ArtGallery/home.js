// Home page JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Featured artworks data (first 6 artworks from the main collection)
    const featuredArtworks = [
        {
            title: "Mona Lisa",
            artist: "Leonardo da Vinci",
            year: "1503-1519",
            image: "https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Mona_Lisa%2C_by_Leonardo_da_Vinci%2C_from_C2RMF_retouched.jpg/220px-Mona_Lisa%2C_by_Leonardo_da_Vinci%2C_from_C2RMF_retouched.jpg",
            description: "The world's most famous painting, Leonardo da Vinci's enigmatic portrait of Lisa Gherardini..."
        },
        {
            title: "Starry Night",
            artist: "Vincent van Gogh",
            year: "1889",
            image: "https://upload.wikimedia.org/wikipedia/commons/thumb/e/ea/Van_Gogh_-_Starry_Night_-_Google_Art_Project.jpg/280px-Van_Gogh_-_Starry_Night_-_Google_Art_Project.jpg",
            description: "Van Gogh's masterpiece depicts a swirling night sky over a village, painted during his stay at the Saint-Paul-de-Mausole asylum..."
        },
        {
            title: "The Great Wave off Kanagawa",
            artist: "Katsushika Hokusai",
            year: "1831",
            image: "https://upload.wikimedia.org/wikipedia/commons/thumb/0/0a/The_Great_Wave_off_Kanagawa.jpg/280px-The_Great_Wave_off_Kanagawa.jpg",
            description: "This iconic woodblock print from Hokusai's series 'Thirty-six Views of Mount Fuji' captures the power and beauty of nature..."
        },
        {
            title: "Girl with a Pearl Earring",
            artist: "Johannes Vermeer",
            year: "1665",
            image: "https://upload.wikimedia.org/wikipedia/commons/thumb/0/0f/1665_Girl_with_a_Pearl_Earring.jpg/220px-1665_Girl_with_a_Pearl_Earring.jpg",
            description: "Often called the 'Mona Lisa of the North,' this masterpiece by Vermeer showcases his exceptional use of light and color..."
        },
        {
            title: "The Persistence of Memory",
            artist: "Salvador Dalí",
            year: "1931",
            image: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/The_Persistence_of_Memory.jpg/280px-The_Persistence_of_Memory.jpg",
            description: "Dalí's surrealist masterpiece featuring melting clocks in a dreamlike landscape explores themes of time and memory..."
        },
        {
            title: "The Birth of Venus",
            artist: "Sandro Botticelli",
            year: "1484-1486",
            image: "https://upload.wikimedia.org/wikipedia/commons/thumb/0/0b/Sandro_Botticelli_-_La_nascita_di_Venere_-_Google_Art_Project_-_edited.jpg/280px-Sandro_Botticelli_-_La_nascita_di_Venere_-_Google_Art_Project_-_edited.jpg",
            description: "This Renaissance masterpiece depicts the Roman goddess Venus emerging from the sea as a fully grown woman..."
        }
    ];

    // Load featured artworks
    function loadFeaturedArtworks() {
        const featuredGrid = document.getElementById('featured-grid');
        if (!featuredGrid) return;

        featuredGrid.innerHTML = '';
        
        featuredArtworks.forEach((artwork, index) => {
            const featuredItem = document.createElement('div');
            featuredItem.className = 'featured-artwork';
            
            featuredItem.innerHTML = `
                <div class="featured-artwork-image">
                    <img src="${artwork.image}" alt="${artwork.title}" loading="lazy" />
                    <div class="featured-overlay">
                        <button class="view-artwork-btn" onclick="viewArtwork(${index})">
                            <i class="fas fa-eye"></i>
                            View Artwork
                        </button>
                    </div>
                </div>
                <div class="featured-artwork-info">
                    <h3>${artwork.title}</h3>
                    <p class="featured-artist">${artwork.artist} • ${artwork.year}</p>
                    <p class="featured-description">${artwork.description.substring(0, 100)}...</p>
                </div>
            `;
            
            featuredGrid.appendChild(featuredItem);
        });

        // Add CSS for featured artworks if not already added
        if (!document.getElementById('featured-styles')) {
            const style = document.createElement('style');
            style.id = 'featured-styles';
            style.textContent = `
                .featured-artwork {
                    background: white;
                    border-radius: 16px;
                    overflow: hidden;
                    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
                    transition: var(--transition-medium);
                    cursor: pointer;
                }
                
                .featured-artwork:hover {
                    transform: translateY(-10px);
                    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.15);
                }
                
                .featured-artwork-image {
                    position: relative;
                    height: 250px;
                    overflow: hidden;
                }
                
                .featured-artwork-image img {
                    width: 100%;
                    height: 100%;
                    object-fit: cover;
                    transition: var(--transition-medium);
                }
                
                .featured-artwork:hover .featured-artwork-image img {
                    transform: scale(1.1);
                }
                
                .featured-overlay {
                    position: absolute;
                    top: 0;
                    left: 0;
                    right: 0;
                    bottom: 0;
                    background: rgba(0, 0, 0, 0.7);
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    opacity: 0;
                    transition: var(--transition-fast);
                }
                
                .featured-artwork:hover .featured-overlay {
                    opacity: 1;
                }
                
                .view-artwork-btn {
                    background: var(--accent-color);
                    color: white;
                    border: none;
                    padding: 1rem 2rem;
                    border-radius: var(--border-radius);
                    font-size: 1rem;
                    font-weight: 500;
                    cursor: pointer;
                    transition: var(--transition-fast);
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                    font-family: 'Poppins', sans-serif;
                }
                
                .view-artwork-btn:hover {
                    background: var(--accent-hover);
                    transform: translateY(-2px);
                }
                
                .featured-artwork-info {
                    padding: 2rem;
                }
                
                .featured-artwork-info h3 {
                    font-size: 1.5rem;
                    font-weight: 600;
                    color: var(--navbar-bg);
                    margin-bottom: 0.5rem;
                }
                
                .featured-artist {
                    color: var(--accent-color);
                    font-weight: 500;
                    margin-bottom: 1rem;
                }
                
                .featured-description {
                    color: var(--text-muted);
                    line-height: 1.6;
                    margin: 0;
                }
                
                @media screen and (max-width: 768px) {
                    .featured-artwork-image {
                        height: 200px;
                    }
                    
                    .featured-artwork-info {
                        padding: 1.5rem;
                    }
                    
                    .featured-artwork-info h3 {
                        font-size: 1.3rem;
                    }
                }
            `;
            document.head.appendChild(style);
        }
    }

    // View artwork function (will redirect to gallery page)
    window.viewArtwork = function(index) {
        // In a real application, you might pass the artwork ID as a URL parameter
        window.location.href = `gallery.html#artwork-${index}`;
    };

    // Parallax effect for hero section
    function setupParallax() {
        const heroSection = document.querySelector('.hero-section-home');
        if (!heroSection) return;

        window.addEventListener('scroll', () => {
            const scrolled = window.pageYOffset;
            const rate = scrolled * -0.5;
            
            if (scrolled < window.innerHeight) {
                heroSection.style.transform = `translateY(${rate}px)`;
            }
        });
    }

    // Counter animation
    function animateCounters() {
        const counters = document.querySelectorAll('.stat h3');
        const speed = 200; // Animation speed

        counters.forEach(counter => {
            const updateCount = () => {
                const target = parseInt(counter.getAttribute('data-target') || counter.textContent);
                const count = parseInt(counter.textContent.replace('+', ''));
                const inc = target / speed;

                if (count < target) {
                    counter.textContent = Math.ceil(count + inc) + '+';
                    setTimeout(updateCount, 1);
                } else {
                    counter.textContent = target + '+';
                }
            };

            // Set data-target attribute
            const currentText = counter.textContent.replace('+', '');
            counter.setAttribute('data-target', currentText);
            counter.textContent = '0+';
            
            // Start animation when element is in viewport
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        updateCount();
                        observer.unobserve(entry.target);
                    }
                });
            });
            
            observer.observe(counter);
        });
    }

    // Smooth reveal animations
    function setupRevealAnimations() {
        const revealElements = document.querySelectorAll('.featured-artwork, .about-preview-text, .about-preview-image, .cta-content');
        
        revealElements.forEach(el => {
            el.style.opacity = '0';
            el.style.transform = 'translateY(50px)';
            el.style.transition = 'opacity 0.8s ease, transform 0.8s ease';
        });

        const observer = new IntersectionObserver((entries) => {
            entries.forEach((entry, index) => {
                if (entry.isIntersecting) {
                    setTimeout(() => {
                        entry.target.style.opacity = '1';
                        entry.target.style.transform = 'translateY(0)';
                    }, index * 100);
                    observer.unobserve(entry.target);
                }
            });
        }, {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        });

        revealElements.forEach(el => observer.observe(el));
    }

    // Image lazy loading optimization
    function optimizeImages() {
        const images = document.querySelectorAll('img[loading="lazy"]');
        
        // Fallback for browsers that don't support native lazy loading
        if ('IntersectionObserver' in window) {
            const imageObserver = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const img = entry.target;
                        img.src = img.dataset.src || img.src;
                        img.classList.remove('lazy');
                        observer.unobserve(img);
                    }
                });
            });

            images.forEach(img => {
                imageObserver.observe(img);
                img.addEventListener('load', () => {
                    img.style.opacity = '1';
                });
            });
        }
    }

    // Initialize all functions
    loadFeaturedArtworks();
    setupParallax();
    animateCounters();
    setupRevealAnimations();
    optimizeImages();

    // Add loading states to CTA buttons
    document.querySelectorAll('.btn-primary, .btn-secondary').forEach(button => {
        button.addEventListener('click', function(e) {
            if (this.href && this.href.includes('gallery.html')) {
                e.preventDefault();
                const originalContent = ArtGalleryUtils.showLoading(this, 'Loading Gallery...');
                
                setTimeout(() => {
                    window.location.href = this.href;
                }, 500);
            }
        });
    });

    // Performance optimization: Preload gallery page
    const galleryLink = document.createElement('link');
    galleryLink.rel = 'prefetch';
    galleryLink.href = 'gallery.html';
    document.head.appendChild(galleryLink);
});

// Add smooth scrolling behavior to hero buttons
document.addEventListener('click', function(e) {
    if (e.target.matches('.btn-primary[href*="gallery"], .btn-secondary[href*="about"]')) {
        e.preventDefault();
        
        // Add subtle loading animation
        const button = e.target;
        const originalTransform = button.style.transform;
        button.style.transform = 'scale(0.95)';
        
        setTimeout(() => {
            button.style.transform = originalTransform;
            window.location.href = button.href;
        }, 150);
    }
});
