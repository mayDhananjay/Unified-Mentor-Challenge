# ArtGallery - Professional Art Collection Website

A beautiful, responsive art gallery website featuring 30+ masterpieces from renowned artists throughout history.

## 🎨 Features

### Multi-Page Architecture
- **Home Page** (`home.html`) - Landing page with hero section, featured artworks, and mission preview
- **Gallery Page** (`gallery.html`) - Complete collection with lightbox viewing
- **About Page** (`about.html`) - Mission, history, team, and values
- **Contact Page** (`contact.html`) - Contact form, location info, and FAQ

### Key Functionality
- ✨ **Responsive Design** - Optimized for all devices
- 🖼️ **Advanced Lightbox** - Detailed artwork viewing with descriptions
- 📱 **Mobile Navigation** - Hamburger menu for mobile devices
- 🎯 **Interactive Forms** - Contact form with validation
- 🚀 **Smooth Animations** - CSS transitions and JavaScript animations
- 📊 **Performance Optimized** - Lazy loading and image optimization

## 📁 File Structure

```
ArtGallery/
├── index.html          # Entry point (redirects to home.html)
├── home.html           # Landing page
├── gallery.html        # Full gallery with lightbox
├── about.html          # About us page
├── contact.html        # Contact page
├── style.css           # Original gallery styles
├── pages-style.css     # Additional page-specific styles
├── script.js           # Gallery functionality
├── home.js             # Home page interactions
├── contact.js          # Contact form handling
├── navigation.js       # Shared navigation functionality
├── firebaseScript.js   # Firebase integration (if needed)
└── README.md           # This file
```

## 🚀 Getting Started

1. Open `index.html` in a web browser (redirects to home page)
2. Or directly open `home.html` to start from the homepage
3. Navigate through the site using the top navigation menu

## 📱 Pages Overview

### 🏠 Home Page (`home.html`)
- **Hero Section**: Welcome message with statistics
- **Featured Artworks**: Preview of 6 selected masterpieces
- **Mission Preview**: Introduction to the gallery's purpose
- **Call-to-Action**: Links to gallery and about pages

### 🖼️ Gallery Page (`gallery.html`)
- **Complete Collection**: All 30 artworks in masonry grid
- **Lightbox Viewing**: Click any artwork for detailed view
- **Rich Descriptions**: Historical context for each piece
- **Navigation Controls**: Previous/Next artwork browsing

### ℹ️ About Page (`about.html`)
- **Mission Statement**: Gallery's purpose and values
- **History Timeline**: Journey from 2020 to present
- **Core Values**: Accessibility, education, preservation, innovation
- **Team Members**: Meet the curators and specialists

### 📞 Contact Page (`contact.html`)
- **Contact Form**: Full validation and error handling
- **Contact Information**: Address, phone, email, hours
- **Location Details**: Transportation and parking info
- **FAQ Section**: Frequently asked questions

## 🎨 Art Collection

The gallery features 30 masterpieces including:

### Renaissance Masters
- Mona Lisa - Leonardo da Vinci
- The Birth of Venus - Sandro Botticelli
- The Creation of Adam - Michelangelo

### Impressionist Works
- Starry Night - Vincent van Gogh
- Water Lilies - Claude Monet
- A Sunday Afternoon... - Georges Seurat

### Modern Art
- The Persistence of Memory - Salvador Dalí
- Campbell's Soup Cans - Andy Warhol
- Composition VII - Wassily Kandinsky

### And many more from various periods and styles!

## 🛠️ Technical Details

### CSS Features
- **CSS Grid & Flexbox** for responsive layouts
- **CSS Variables** for consistent theming
- **CSS Animations** for smooth interactions
- **Mobile-first** responsive design

### JavaScript Features
- **Modular Structure** with separate files per page
- **Form Validation** with real-time feedback
- **Lightbox Gallery** with keyboard navigation
- **Intersection Observer** for scroll animations
- **Local Storage** for form auto-save

### Browser Support
- Modern browsers (Chrome, Firefox, Safari, Edge)
- Mobile browsers (iOS Safari, Chrome Mobile)
- Progressive enhancement for older browsers

## 🎯 Customization

### Adding New Artworks
1. Edit `script.js` and add to the `artworks` array
2. Include title, artist, year, image URL, and description

### Styling Changes
- Main gallery styles: `style.css`
- Page-specific styles: `pages-style.css`
- Use CSS custom properties (variables) for consistent theming

### Content Updates
- Update HTML files directly for static content
- Modify JavaScript arrays for dynamic content
- Replace images in the `images/` folder if using local images

## 🌟 Features in Detail

### Lightbox Gallery
- **Keyboard Navigation**: Arrow keys, Escape
- **Touch Support**: Swipe gestures on mobile
- **Image Preloading**: Smooth transitions
- **Rich Descriptions**: Historical context and analysis

### Contact Form
- **Real-time Validation**: Immediate feedback
- **Auto-save**: Form data preserved
- **Success Handling**: Confirmation messages
- **Accessibility**: Screen reader friendly

### Navigation
- **Active States**: Current page highlighting
- **Mobile Menu**: Hamburger toggle
- **Smooth Scrolling**: Enhanced user experience
- **Loading States**: Visual feedback

## 📱 Responsive Design

### Desktop (1024px+)
- Full navigation bar
- Multi-column layouts
- Hover effects and animations

### Tablet (768px - 1024px)
- Adapted layouts
- Touch-friendly interfaces
- Optimized image sizes

### Mobile (320px - 768px)
- Hamburger navigation
- Single-column layouts
- Gesture-based interactions

## 🚀 Performance

- **Lazy Loading**: Images load as needed
- **Optimized Images**: Proper sizing and formats
- **Minified Assets**: Reduced file sizes
- **Caching Headers**: Improved load times

## 🔧 Maintenance

### Regular Updates
- Keep artwork descriptions current
- Update team member information
- Refresh contact details
- Add new artworks to collection

### SEO Optimization
- Meta tags included for all pages
- Open Graph tags for social sharing
- Semantic HTML structure
- Alt text for all images

---

**Created with ❤️ for art enthusiasts worldwide**

For questions or suggestions, please use the contact form on the website.
